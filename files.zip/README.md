# HN Daily Digest Agent

每天从 Hacker News 抓取热榜，用 Claude 为每条生成结构化中文（或英文）摘要，输出一份可读的 Markdown + HTML 日报。

```
topstories ──► 抓元数据 ──► 抓正文 + 热门评论 ──► Claude 摘要 ──► Markdown + HTML
                (并发)        (并发)             (并发, 默认 Haiku 4.5)
```

每条产出：一句话概要 · 3–5 条要点 · 评论区观点/分歧 · 主题标签。

---

## 安装

```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY=sk-ant-...
```

## 运行

```bash
python hn_digest.py                              # 热榜前 30，中文摘要，输出到 ./digests/
python hn_digest.py --num 20 --lang en           # 前 20，英文摘要
python hn_digest.py --keywords AI,LLM,crypto,Rust # 只保留标题命中关键词的故事（个性化日报）
python hn_digest.py --proxy http://127.0.0.1:7897 # API 与正文抓取都走本地代理
python hn_digest.py --no-articles                # 只用标题 + 评论（更快、更省）
```

输出文件：`digests/hn-digest-YYYY-MM-DD.md` 和 `.html`。HTML 是自包含单文件，可直接浏览器打开或作为邮件正文。

## 常用参数

| 参数 | 默认 | 说明 |
|---|---|---|
| `--num N` | 30 | 摘要的故事数 |
| `--model ID` | `claude-haiku-4-5-20251001` | 换 `claude-sonnet-4-6` 可提质，成本约 3× |
| `--lang zh\|en` | `zh` | 摘要语言（标签/版式同步切换）|
| `--keywords a,b,c` | 无 | 按标题关键词过滤；命中前会先抓 `--pool`（默认 120）条做筛选 |
| `--concurrency N` | 6 | 并发摘要槽位（抓正文 + 调模型）|
| `--max-comments N` | 8 | 喂给模型的热门评论条数 |
| `--proxy URL` | `$HTTPS_PROXY` | 代理；也可用环境变量 `HN_DIGEST_PROXY` |
| `--no-cache` | — | 强制重新摘要（默认按故事 id 缓存，避免重复付费）|

## 定时（每天早上 8 点）

```cron
0 8 * * * cd /path/to/hn-agent && ANTHROPIC_API_KEY=sk-ant-... \
  /usr/bin/python3 hn_digest.py --num 30 >> digests/run.log 2>&1
```

## 成本

默认 Haiku 4.5（$1 / $5 每百万 tokens，官方推荐用于摘要类任务）。30 条全量摘要单次约 **$0.15–0.30**；长期跑会因为热榜常驻故事命中缓存而更低。换 Sonnet 4.6 质量更高、成本约 3 倍。

## 工作方式

- **HN API**：无需鉴权的 Firebase 接口。`topstories.json` 取排名，`item/{id}.json` 取每条详情、`kids` 取评论。带 3 次重试。
- **正文抽取**：`httpx` 拉 HTML，`trafilatura` 提取正文（自动跳过 PDF/视频等非 HTML；Ask/Show HN 直接用帖子自带 `text`）。正文超长按字符截断。
- **摘要**：每条一次模型调用，要求只返回 JSON（`summary` / `key_points` / `discussion` / `tags`），解析容错（去 ``` 包裹、兜底正则提取）。token 用量累加并在结束时给出估算成本。
- **缓存**：`digests/.cache/{id}.json` 按故事 id 缓存摘要——常驻热榜的故事跨天不重复付费。注意评论是基于首次摘要时的快照；要刷新加 `--no-cache`。

## 可扩展方向

- 接入邮件：把 `hn-digest-*.html` 作为正文发给自己（SMTP 或任意邮件 API）。
- 更"代理化"：把"判断哪些故事值得深挖"交给模型做一次筛选/打分，而非纯关键词；或加 `tool_use` 让模型按需追加抓取。
- 换数据源：`topstories` 换成 `beststories`（高赞）或 `newstories`（最新）即可，逻辑不变。
