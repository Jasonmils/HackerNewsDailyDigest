#!/usr/bin/env python3
"""
hn_digest.py — Hacker News 每日热榜 Agent

Pipeline:
  1. Fetch top story IDs from the Hacker News Firebase API
  2. Concurrently fetch each story's metadata, article body, and top comments
  3. Summarize each story with Claude (TL;DR + key points + discussion themes + tags)
  4. Render a daily digest as Markdown (+ a self-contained HTML reading page)

Usage:
  export ANTHROPIC_API_KEY=sk-ant-...
  python hn_digest.py                          # top 30, Chinese summaries, Markdown + HTML
  python hn_digest.py --num 20 --lang en       # top 20, English summaries
  python hn_digest.py --keywords AI,LLM,crypto # only stories whose title matches a keyword
  python hn_digest.py --proxy http://127.0.0.1:7897   # route API + fetches through a local proxy

Requires: anthropic, httpx, trafilatura  (see requirements.txt)
"""

from __future__ import annotations

import argparse
import asyncio
import html
import json
import os
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import httpx
import trafilatura
from anthropic import AsyncAnthropic

try:
    from anthropic import DefaultAsyncHttpxClient
except ImportError:  # older SDKs
    DefaultAsyncHttpxClient = None

# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #
HN_API = "https://hacker-news.firebaseio.com/v0"
HN_ITEM_URL = "https://news.ycombinator.com/item?id={}"

# Standard list prices, USD per 1M tokens (input, output). Used only for the
# rough cost line printed at the end — update if Anthropic changes rates.
PRICING = {
    "claude-haiku-4-5-20251001": (1.0, 5.0),
    "claude-haiku-4-5": (1.0, 5.0),
    "claude-sonnet-4-6": (3.0, 15.0),
    "claude-opus-4-8": (5.0, 25.0),
}

DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; HN-Digest/1.0; +https://news.ycombinator.com)",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en;q=0.9",
}

LABELS = {
    "zh": {
        "title": "Hacker News 每日热榜", "count": "条", "model": "模型",
        "points": "分", "comments": "评论", "hn": "HN 讨论", "summary": "概要",
        "keypoints": "要点", "discussion": "讨论", "failed": "处理失败",
        "noinfo": "未能抓取正文，以下基于标题与讨论",
    },
    "en": {
        "title": "Hacker News Daily", "count": "stories", "model": "model",
        "points": "points", "comments": "comments", "hn": "HN thread", "summary": "Summary",
        "keypoints": "Key points", "discussion": "Discussion", "failed": "failed",
        "noinfo": "Article body unavailable; summary based on title and discussion",
    },
}

TAG_RE = re.compile(r"<[^>]+>")


# --------------------------------------------------------------------------- #
# Config
# --------------------------------------------------------------------------- #
@dataclass
class Config:
    num_stories: int = 30
    model: str = "claude-haiku-4-5-20251001"
    lang: str = "zh"                  # "zh" | "en"
    keywords: list[str] = field(default_factory=list)
    pool: int = 120                   # candidate pool size when filtering by keyword
    max_concurrency: int = 6          # parallel article-fetch + LLM slots
    meta_concurrency: int = 20        # parallel HN metadata fetches (cheap)
    max_comments: int = 8             # top-level comments fed to the summarizer
    article_char_limit: int = 12_000
    comment_char_limit: int = 4_000
    request_timeout: float = 25.0
    output_dir: Path = Path("./digests")
    proxy: Optional[str] = None
    fetch_articles: bool = True
    html: bool = True
    cache: bool = True


@dataclass
class StoryResult:
    rank: int
    id: int
    title: str
    url: str
    hn_url: str
    score: int
    by: str
    comments_count: int
    summary: Optional[dict] = None
    error: Optional[str] = None
    cached: bool = False


# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #
def html_to_text(s: str) -> str:
    """HN comment/post bodies are small HTML fragments."""
    if not s:
        return ""
    s = s.replace("</p>", "\n\n").replace("<p>", "\n\n")
    s = TAG_RE.sub("", s)
    return html.unescape(s).strip()


async def _none() -> None:
    return None


def parse_json(raw: str) -> Optional[dict]:
    """Tolerant JSON extraction from a model response."""
    if not raw:
        return None
    raw = raw.strip()
    raw = re.sub(r"^```(?:json)?", "", raw).strip()
    raw = re.sub(r"```$", "", raw).strip()
    try:
        return json.loads(raw)
    except Exception:
        m = re.search(r"\{.*\}", raw, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                return None
    return None


# --------------------------------------------------------------------------- #
# Hacker News API client
# --------------------------------------------------------------------------- #
class HNClient:
    def __init__(self, http: httpx.AsyncClient, timeout: float):
        self.http = http
        self.timeout = timeout

    async def _get_json(self, path: str) -> Any:
        last: Optional[Exception] = None
        for attempt in range(3):
            try:
                r = await self.http.get(f"{HN_API}/{path}.json", timeout=self.timeout)
                r.raise_for_status()
                return r.json()
            except Exception as e:  # transient Firebase hiccups
                last = e
                await asyncio.sleep(0.5 * (attempt + 1))
        raise last  # type: ignore[misc]

    async def top_story_ids(self, n: int) -> list[int]:
        ids = await self._get_json("topstories")
        return (ids or [])[:n]

    async def item(self, item_id: int) -> dict:
        data = await self._get_json(f"item/{item_id}")
        return data or {}


async def fetch_items(hn: HNClient, ids: list[int], concurrency: int) -> list[Optional[dict]]:
    sem = asyncio.Semaphore(concurrency)

    async def one(i: int) -> Optional[dict]:
        async with sem:
            try:
                return await hn.item(i)
            except Exception:
                return None

    return await asyncio.gather(*[one(i) for i in ids])


async def fetch_top_comments(hn: HNClient, story: dict, limit: int, char_limit: int) -> list[dict]:
    kids = (story.get("kids") or [])[:limit]
    if not kids:
        return []
    raw = await asyncio.gather(*[hn.item(k) for k in kids], return_exceptions=True)
    out: list[dict] = []
    used = 0
    for c in raw:
        if isinstance(c, Exception) or not c:
            continue
        if c.get("type") != "comment" or c.get("dead") or c.get("deleted"):
            continue
        text = html_to_text(c.get("text", ""))
        if not text:
            continue
        if used + len(text) > char_limit:
            text = text[: max(0, char_limit - used)]
        out.append({"by": c.get("by", "anon"), "text": text})
        used += len(text)
        if used >= char_limit:
            break
    return out


# --------------------------------------------------------------------------- #
# Article fetching
# --------------------------------------------------------------------------- #
async def fetch_article_text(
    http: httpx.AsyncClient, url: str, timeout: float, char_limit: int
) -> Optional[str]:
    try:
        r = await http.get(url, timeout=timeout, follow_redirects=True, headers=DEFAULT_HEADERS)
    except Exception:
        return None
    if r.status_code != 200:
        return None
    ctype = r.headers.get("content-type", "").lower()
    if "html" not in ctype and "text/plain" not in ctype:
        return None  # PDFs, video, images, etc.
    try:
        extracted = trafilatura.extract(
            r.text, include_comments=False, include_tables=True, favor_recall=True
        )
    except Exception:
        return None
    if not extracted:
        return None
    extracted = extracted.strip()
    if len(extracted) > char_limit:
        extracted = extracted[:char_limit] + "\n\n[... truncated ...]"
    return extracted


# --------------------------------------------------------------------------- #
# Summarization (Claude)
# --------------------------------------------------------------------------- #
def build_system(lang: str) -> str:
    if lang == "zh":
        return (
            "你是一位资深科技分析师，为忙碌的技术读者撰写 Hacker News 每日热榜摘要。"
            "摘要要准确、精炼、信息密度高，直入主题，避免营销腔与空话；不要编造原文中没有的事实。"
            "始终只返回一个 JSON 对象，不包含任何额外文字、说明或 Markdown 代码块。"
        )
    return (
        "You are a senior tech analyst writing daily Hacker News digests for busy technical "
        "readers. Summaries must be accurate, concise, and information-dense — no marketing "
        "tone, no filler, and never invent facts not present in the source. Always return a "
        "single JSON object with no extra text, explanation, or Markdown fences."
    )


def build_prompt(story: dict, article_text: Optional[str], comments: list[dict], lang: str) -> str:
    title = story.get("title", "")
    url = story.get("url", "")
    post_body = html_to_text(story.get("text", ""))  # Ask HN / Show HN bodies

    parts: list[str] = [f"Title: {title}"]
    if url:
        parts.append(f"URL: {url}")
    if post_body:
        parts.append(f"Original post:\n{post_body}")
    if article_text:
        parts.append(f"Article content:\n{article_text}")
    elif not post_body:
        parts.append(
            "(The article body could not be fetched. Summarize from the title and the "
            "discussion only, and note in `summary` that information is limited.)"
        )
    if comments:
        block = "\n\n".join(f"[{c['by']}] {c['text']}" for c in comments)
        parts.append(f"Top Hacker News comments:\n{block}")

    if lang == "zh":
        schema = (
            "请用简体中文输出一个 JSON 对象，字段如下：\n"
            '  "summary": 字符串，2-3 句话概括这条内容的核心；\n'
            '  "key_points": 字符串数组，3-5 条最关键的事实或论点；\n'
            '  "discussion": 字符串，1-2 句话总结 HN 评论区的主要观点或分歧（无评论则写空字符串）；\n'
            '  "tags": 字符串数组，2-4 个主题标签（如 "AI"、"开源"、"安全"）。\n'
            "只输出该 JSON，不要任何其他内容。"
        )
    else:
        schema = (
            "Output a single JSON object in English with these fields:\n"
            '  "summary": string, 2-3 sentences capturing the core of the item;\n'
            '  "key_points": array of 3-5 strings, the most important facts or arguments;\n'
            '  "discussion": string, 1-2 sentences on the main themes or disagreements in the '
            "HN comments (empty string if none);\n"
            '  "tags": array of 2-4 topic tags (e.g. "AI", "open-source", "security").\n'
            "Output only the JSON, nothing else."
        )
    parts.append(schema)
    return "\n\n".join(parts)


async def summarize_story(
    anthropic: AsyncAnthropic,
    model: str,
    story: dict,
    article_text: Optional[str],
    comments: list[dict],
    lang: str,
    usage: dict,
) -> tuple[Optional[dict], Optional[str]]:
    prompt = build_prompt(story, article_text, comments, lang)
    try:
        msg = await anthropic.messages.create(
            model=model,
            max_tokens=1200,
            system=build_system(lang),
            messages=[{"role": "user", "content": prompt}],
        )
    except Exception as e:
        return None, f"LLM error: {e}"

    usage["input"] += msg.usage.input_tokens
    usage["output"] += msg.usage.output_tokens
    raw = "".join(b.text for b in msg.content if getattr(b, "type", None) == "text")
    parsed = parse_json(raw)
    if parsed is None:
        return None, "could not parse model JSON"
    return parsed, None


# --------------------------------------------------------------------------- #
# Per-story orchestration
# --------------------------------------------------------------------------- #
class Cache:
    def __init__(self, root: Path, enabled: bool):
        self.root = root / ".cache"
        self.enabled = enabled
        if enabled:
            self.root.mkdir(parents=True, exist_ok=True)

    def get(self, item_id: int) -> Optional[dict]:
        if not self.enabled:
            return None
        p = self.root / f"{item_id}.json"
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                return None
        return None

    def set(self, item_id: int, summary: dict) -> None:
        if not self.enabled or summary is None:
            return
        try:
            (self.root / f"{item_id}.json").write_text(
                json.dumps(summary, ensure_ascii=False), encoding="utf-8"
            )
        except Exception:
            pass


@dataclass
class Ctx:
    hn: HNClient
    http: httpx.AsyncClient
    anthropic: AsyncAnthropic
    cfg: Config
    sem: asyncio.Semaphore
    usage: dict
    cache: Cache


async def summarize_one(rank: int, story: dict, ctx: Ctx) -> StoryResult:
    cfg = ctx.cfg
    sid = int(story.get("id"))
    url = story.get("url", "")
    res = StoryResult(
        rank=rank,
        id=sid,
        title=story.get("title", ""),
        url=url,
        hn_url=HN_ITEM_URL.format(sid),
        score=story.get("score", 0),
        by=story.get("by", "anon"),
        comments_count=story.get("descendants", 0),
    )

    cached = ctx.cache.get(sid)
    if cached:
        res.summary = cached
        res.cached = True
        return res

    async with ctx.sem:
        article_task = (
            fetch_article_text(ctx.http, url, cfg.request_timeout, cfg.article_char_limit)
            if (url and cfg.fetch_articles)
            else _none()
        )
        comments_task = fetch_top_comments(ctx.hn, story, cfg.max_comments, cfg.comment_char_limit)
        article_text, comments = await asyncio.gather(article_task, comments_task)
        summary, err = await summarize_story(
            ctx.anthropic, cfg.model, story, article_text, comments, cfg.lang, ctx.usage
        )

    res.summary = summary
    res.error = err
    if summary:
        ctx.cache.set(sid, summary)
    return res


# --------------------------------------------------------------------------- #
# Rendering
# --------------------------------------------------------------------------- #
def render_markdown(results: list[StoryResult], cfg: Config, generated_at: datetime) -> str:
    lbl = LABELS[cfg.lang]
    date_str = generated_at.strftime("%Y-%m-%d")
    ok = [r for r in results if r and r.summary]
    out: list[str] = [f"# {lbl['title']} · {date_str}", ""]
    out.append(
        f"> {len(ok)} {lbl['count']} · {generated_at.strftime('%Y-%m-%d %H:%M %Z')} · "
        f"{lbl['model']} `{cfg.model}`"
    )
    out.append("")
    for r in results:
        if not r:
            continue
        out.append(f"## {r.rank}. [{r.title}]({r.url or r.hn_url})")
        out.append(
            f"▲ {r.score} {lbl['points']} · {r.by} · "
            f"[{r.comments_count} {lbl['comments']}]({r.hn_url})"
        )
        out.append("")
        s = r.summary
        if s:
            if s.get("summary"):
                out.append(f"📝 **{lbl['summary']}**：{s['summary']}")
            kps = s.get("key_points") or []
            if kps:
                out.append("")
                out.append(f"**🔑 {lbl['keypoints']}**")
                out.extend(f"- {p}" for p in kps)
            if s.get("discussion"):
                out.append("")
                out.append(f"💬 **{lbl['discussion']}**：{s['discussion']}")
            tags = s.get("tags") or []
            if tags:
                out.append("")
                out.append("🏷️ " + " · ".join(f"`{t}`" for t in tags))
        elif r.error:
            out.append(f"_({lbl['failed']}: {r.error})_")
        out.extend(["", "---", ""])
    return "\n".join(out)


CSS_BLOCK = """
:root{
  --bg:#FCFCFA; --ink:#1B1B1B; --muted:#6F6F68; --hair:#E7E6DF;
  --hn:#FF6600; --hn-soft:#FFF1E8; --card:#FFFFFF;
  --body:"Inter","Helvetica Neue",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Hiragino Sans","Noto Sans CJK SC","PingFang SC","Microsoft YaHei",sans-serif;
  --mono:ui-monospace,"SF Mono","JetBrains Mono","Roboto Mono",Menlo,Consolas,monospace;
}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--ink);font-family:var(--body);
  line-height:1.66;font-size:16.5px;-webkit-font-smoothing:antialiased}
.wrap{max-width:720px;margin:0 auto;padding:0 22px}
header{border-bottom:2px solid var(--ink);margin:34px auto 6px;max-width:720px;padding:0 22px 14px}
header .mast{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
header h1{font-family:var(--mono);font-size:clamp(22px,5vw,30px);font-weight:700;
  letter-spacing:-.01em;margin:0}
header h1 .y{color:var(--hn)}
header .sub{font-family:var(--mono);color:var(--muted);font-size:12.5px;margin:8px 0 0;
  text-transform:uppercase;letter-spacing:.06em}
main{padding-bottom:64px}
.card{border-bottom:1px solid var(--hair);padding:26px 0 24px}
.card:last-child{border-bottom:none}
.head{display:flex;gap:14px;align-items:flex-start}
.rank{font-family:var(--mono);font-size:14px;font-weight:700;color:var(--hn);
  line-height:1.5;min-width:30px;padding-top:2px;font-variant-numeric:tabular-nums}
.card h2{font-size:20px;font-weight:650;line-height:1.32;margin:0;letter-spacing:-.01em}
.card h2 a{color:var(--ink);text-decoration:none;border-bottom:1.5px solid transparent;
  transition:border-color .12s ease,color .12s ease}
.card h2 a:hover{color:var(--hn);border-bottom-color:var(--hn)}
.meta{font-family:var(--mono);color:var(--muted);font-size:12.5px;margin:7px 0 0 44px;
  font-variant-numeric:tabular-nums}
.meta a{color:var(--muted);text-decoration:none;border-bottom:1px dotted var(--muted)}
.meta a:hover{color:var(--hn);border-bottom-color:var(--hn)}
.body{margin:14px 0 0 44px}
.summary{margin:0}
.kp{margin:12px 0 0;padding:0;list-style:none}
.kp li{position:relative;padding-left:18px;margin:5px 0}
.kp li::before{content:"";position:absolute;left:0;top:.66em;width:5px;height:5px;
  background:var(--hn);border-radius:50%}
.disc{margin:14px 0 0;padding:11px 14px;background:var(--hn-soft);border-radius:8px;
  font-size:15px}
.disc strong{font-weight:650}
.tags{margin:14px 0 0;display:flex;flex-wrap:wrap;gap:7px}
.tag{font-family:var(--mono);font-size:11.5px;color:var(--muted);
  border:1px solid var(--hair);border-radius:999px;padding:3px 10px}
.err{margin:10px 0 0 44px;color:#A33;font-size:14px;font-family:var(--mono)}
footer{max-width:720px;margin:0 auto;padding:0 22px 48px;color:var(--muted);
  font-family:var(--mono);font-size:11.5px;text-transform:uppercase;letter-spacing:.06em}
@media(max-width:560px){
  .meta,.body,.err{margin-left:0}
  .rank{min-width:26px}
}
"""


def render_html(results: list[StoryResult], cfg: Config, generated_at: datetime) -> str:
    lbl = LABELS[cfg.lang]
    date_str = generated_at.strftime("%Y-%m-%d")
    ok = [r for r in results if r and r.summary]

    cards: list[str] = []
    for r in results:
        if not r:
            continue
        s = r.summary or {}
        title = html.escape(r.title)
        link = html.escape(r.url or r.hn_url, quote=True)
        hn = html.escape(r.hn_url, quote=True)
        summ = html.escape(s.get("summary", "")) if s else ""
        kps = "".join(f"<li>{html.escape(p)}</li>" for p in (s.get("key_points") or []))
        disc = html.escape(s.get("discussion", "")) if s else ""
        tags = "".join(f'<span class="tag">{html.escape(t)}</span>' for t in (s.get("tags") or []))

        body_bits: list[str] = []
        if summ:
            body_bits.append(f'<p class="summary">{summ}</p>')
        if kps:
            body_bits.append(f'<ul class="kp">{kps}</ul>')
        if disc:
            body_bits.append(f'<p class="disc"><strong>💬 {lbl["discussion"]}</strong> {disc}</p>')
        if tags:
            body_bits.append(f'<div class="tags">{tags}</div>')
        body = f'<div class="body">{"".join(body_bits)}</div>' if body_bits else ""
        err = "" if s else f'<p class="err">{html.escape(r.error or lbl["failed"])}</p>'

        cards.append(
            f'<article class="card">'
            f'<div class="head"><span class="rank">{r.rank:02d}</span>'
            f'<h2><a href="{link}" target="_blank" rel="noopener">{title}</a></h2></div>'
            f'<div class="meta">▲ {r.score} {lbl["points"]} · {html.escape(r.by)} · '
            f'<a href="{hn}" target="_blank" rel="noopener">{r.comments_count} {lbl["comments"]}</a></div>'
            f"{body}{err}</article>"
        )

    body_html = "\n".join(cards)
    gen = html.escape(generated_at.strftime("%Y-%m-%d %H:%M %Z"))
    model = html.escape(cfg.model)
    return (
        "<!doctype html>\n"
        f'<html lang="{cfg.lang}">\n<head>\n'
        '<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
        f"<title>{lbl['title']} · {date_str}</title>\n"
        f"<style>{CSS_BLOCK}</style>\n</head>\n<body>\n"
        '<header><div class="mast">'
        f'<h1><span class="y">Y</span> {lbl["title"]}</h1></div>'
        f'<p class="sub">{date_str} &nbsp;·&nbsp; {len(ok)} {lbl["count"]} &nbsp;·&nbsp; {model}</p>'
        "</header>\n"
        f'<main><div class="wrap">\n{body_html}\n</div></main>\n'
        f"<footer>generated {gen} · hn-digest agent</footer>\n"
        "</body>\n</html>\n"
    )


# --------------------------------------------------------------------------- #
# Runner
# --------------------------------------------------------------------------- #
def build_anthropic(api_key: str, proxy: Optional[str]):
    if proxy and DefaultAsyncHttpxClient is not None:
        return AsyncAnthropic(api_key=api_key, http_client=DefaultAsyncHttpxClient(proxy=proxy)), None
    if proxy:
        client = httpx.AsyncClient(proxy=proxy)
        return AsyncAnthropic(api_key=api_key, http_client=client), client
    return AsyncAnthropic(api_key=api_key), None


async def run(cfg: Config) -> list[Path]:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        sys.exit("ERROR: ANTHROPIC_API_KEY is not set.")

    limits = httpx.Limits(max_connections=cfg.max_concurrency * 4 + cfg.meta_concurrency)
    http = httpx.AsyncClient(proxy=cfg.proxy, limits=limits, headers=DEFAULT_HEADERS)
    anthropic, extra_client = build_anthropic(api_key, cfg.proxy)
    hn = HNClient(http, cfg.request_timeout)
    ctx = Ctx(
        hn=hn, http=http, anthropic=anthropic, cfg=cfg,
        sem=asyncio.Semaphore(cfg.max_concurrency),
        usage={"input": 0, "output": 0},
        cache=Cache(cfg.output_dir, cfg.cache),
    )

    log = lambda m: print(m, file=sys.stderr, flush=True)
    try:
        pool_n = cfg.pool if cfg.keywords else cfg.num_stories
        log(f"› Fetching top {pool_n} story IDs …")
        ids = await hn.top_story_ids(pool_n)

        log(f"› Fetching metadata for {len(ids)} stories …")
        items = [it for it in await fetch_items(hn, ids, cfg.meta_concurrency) if it and it.get("title")]

        if cfg.keywords:
            kws = [k.strip().lower() for k in cfg.keywords if k.strip()]
            items = [it for it in items if any(k in it["title"].lower() for k in kws)]
            log(f"› {len(items)} stories match keywords {kws}")

        selected = items[: cfg.num_stories]
        if not selected:
            log("› No stories to summarize.")
            return []

        log(f"› Summarizing {len(selected)} stories with {cfg.model} …")
        results = await asyncio.gather(
            *[summarize_one(i + 1, it, ctx) for i, it in enumerate(selected)]
        )
    finally:
        await http.aclose()
        if extra_client is not None:
            await extra_client.aclose()
        try:
            await anthropic.close()
        except Exception:
            pass

    generated_at = datetime.now().astimezone()
    date_str = generated_at.strftime("%Y-%m-%d")
    cfg.output_dir.mkdir(parents=True, exist_ok=True)

    md_path = cfg.output_dir / f"hn-digest-{date_str}.md"
    md_path.write_text(render_markdown(results, cfg, generated_at), encoding="utf-8")
    paths = [md_path]
    if cfg.html:
        html_path = cfg.output_dir / f"hn-digest-{date_str}.html"
        html_path.write_text(render_html(results, cfg, generated_at), encoding="utf-8")
        paths.append(html_path)

    n_ok = sum(1 for r in results if r and r.summary)
    n_cached = sum(1 for r in results if r and r.cached)
    pin, pout = PRICING.get(cfg.model, (0.0, 0.0))
    cost = ctx.usage["input"] / 1e6 * pin + ctx.usage["output"] / 1e6 * pout
    log(f"✓ {n_ok}/{len(results)} summarized ({n_cached} from cache)")
    log(
        f"  tokens: {ctx.usage['input']:,} in / {ctx.usage['output']:,} out  ≈ ${cost:.4f}"
    )
    for p in paths:
        log(f"  → {p}")
    return paths


def parse_args() -> Config:
    p = argparse.ArgumentParser(description="Hacker News 每日热榜 Agent")
    p.add_argument("--num", type=int, default=30, help="number of stories (default 30)")
    p.add_argument("--model", default="claude-haiku-4-5-20251001", help="Claude model id")
    p.add_argument("--lang", choices=["zh", "en"], default="zh", help="summary language")
    p.add_argument("--keywords", default="", help="comma-separated title filter, e.g. AI,LLM,crypto")
    p.add_argument("--pool", type=int, default=120, help="candidate pool when filtering by keyword")
    p.add_argument("--concurrency", type=int, default=6, help="parallel summarization slots")
    p.add_argument("--max-comments", type=int, default=8, help="top comments fed to the model")
    p.add_argument("--out", default="./digests", help="output directory")
    p.add_argument(
        "--proxy",
        default=os.environ.get("HN_DIGEST_PROXY") or os.environ.get("HTTPS_PROXY"),
        help="proxy URL for the API and article fetches (e.g. http://127.0.0.1:7897)",
    )
    p.add_argument("--no-articles", action="store_true", help="skip article fetch (title + comments only)")
    p.add_argument("--no-html", action="store_true", help="Markdown only, skip the HTML page")
    p.add_argument("--no-cache", action="store_true", help="force fresh summaries")
    a = p.parse_args()
    return Config(
        num_stories=a.num,
        model=a.model,
        lang=a.lang,
        keywords=[k for k in a.keywords.split(",") if k.strip()],
        pool=a.pool,
        max_concurrency=a.concurrency,
        max_comments=a.max_comments,
        output_dir=Path(a.out),
        proxy=a.proxy,
        fetch_articles=not a.no_articles,
        html=not a.no_html,
        cache=not a.no_cache,
    )


if __name__ == "__main__":
    try:
        asyncio.run(run(parse_args()))
    except KeyboardInterrupt:
        sys.exit(130)
